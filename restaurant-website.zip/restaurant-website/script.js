document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Thank you! Your reservation has been submitted.");
});